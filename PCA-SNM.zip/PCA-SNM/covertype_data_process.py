#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/4/19 3:59 下午
# @Contact : haozhou0806@gmail.com
# @Site    : https://zhouh.github.io/
# @File    : covertype_data.py

# spliting the data into training test and validation

