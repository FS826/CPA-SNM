import numpy as np
from logistic_oracles import *
import random, time
import matplotlib.pyplot as plt


def sgd(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []

	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()


	for curr_iter in range(int(num_iter)):
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)

		curr_x = curr_x - curr_grad

		print 'epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1]

	output_data = {'epochs': epochs, 'wall_times': wall_times, 'trainerror': trainerror}
	print output_data
	return curr_x, output_data

def lissa_main(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []
	
	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()

	for curr_iter in range(int(num_iter)):		
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)

		curr_grad = curr_grad.flatten('F')
		curr_step = np.zeros(curr_grad.shape)
		
		for lissa_iter in range(num_lissa_iter):
			rand_index = random.sample(range(num_examples), hessian_batch_size)
			sub_step = data_holder.batch_hess_vec_product(rand_index, curr_x, curr_step)
			curr_quad_step = curr_grad - sub_step
			
			curr_step = curr_step + quad_stepsize*curr_quad_step

		curr_x = curr_x - np.reshape(curr_step, data_holder.data_dim, 'F')
		print 'epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1]

	output_data = [epochs,  wall_times, trainerror]
	print output_data

	# min_train_error = min(trainerror)
	# for i in range(len(trainerror)):
	# 	trainerror[i] = np.log(trainerror[i] - min_train_error)



	# f=open('1e-4_result_lissa.'+data_holder.dataset,'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	# f = open('s2_25_lissa.txt', 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	return curr_x, output_data



def lissa_chebyshev_semi_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder, chebyshev_alpha, chebyshev_beta):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []

	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()

	for curr_iter in range(int(num_iter)):
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		#trainerror += [data_holder.batch_accuracy(range(0, num_examples), curr_x)]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)


		curr_grad = curr_grad.flatten('F')
		curr_step = np.zeros(curr_grad.shape)

		last_step = curr_grad
		initial_step = True

		# define the coefficients for the modified lissa iteration via  chebyshev semi iteration method

		alpha = 1.0 - chebyshev_beta
		beta = 1.0 - chebyshev_alpha
		xi = (2.0 - alpha - beta) / (beta - alpha)
		gamma = 2.0 / (2 - beta - alpha)

		rpho = 2.0
		extra_term = np.zeros(curr_x.size)

		init_gamma = gamma

		for lissa_iter in range(num_lissa_iter):

			if not initial_step:

				# begin to apply chebyshev semi iteration
				rpho = 1 / (1 - rpho / (4 * math.pow(xi, 2)) )

				extra_term = rpho * (1 - gamma) * curr_step + (1 - rpho) * last_step

				last_step = curr_step

			# the same as orginal, for computing the gradients * subgradients
			rand_index = random.sample(range(num_examples), hessian_batch_size)
			sub_step = data_holder.batch_hess_vec_product(rand_index, curr_x, curr_step)
			curr_quad_step = curr_grad - sub_step
			curr_step = curr_step + init_gamma * curr_quad_step

			if initial_step:
				initial_step = False
				init_gamma = 1
				continue
			else:
				curr_step = extra_term + rpho * gamma * curr_step


		curr_x = curr_x -np.reshape(curr_step, data_holder.data_dim, 'F')

		print 'epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1]


	output_data = [epochs,  wall_times, trainerror]
	print output_data
	# min_train_error = min(trainerror)
	# for i in range(len(trainerror)):
	# 	trainerror[i] = np.log(trainerror[i] - min_train_error)

	# print(output_data)
	# f = open('1e-4_result_cheb.'+data_holder.dataset, 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	# f = open('s2_25_cheb.txt', 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	return curr_x, output_data

def one_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder, chebyshev_alpha, chebyshev_beta):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []

	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()

	for curr_iter in range(int(num_iter)):
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		#trainerror += [data_holder.batch_accuracy(range(0, num_examples), curr_x)]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)


		curr_grad = curr_grad.flatten('F')
		curr_step = np.zeros(curr_grad.shape)

		last_step = curr_grad
		initial_step = True

		# define the coefficients for the modified lissa iteration via  chebyshev semi iteration method

		alpha = 1.0 - chebyshev_beta
		beta = 1.0 - chebyshev_alpha
		xi = (2.0 - alpha - beta) / (beta - alpha)
		gamma = 2.0 / (2 - beta - alpha)

		rpho = 1.0
		extra_term = np.zeros(curr_x.size)

		init_gamma = gamma

		for lissa_iter in range(num_lissa_iter):

			if not initial_step:

				# begin to apply chebyshev semi iteration
				#rpho = 1 / (1 - rpho / (4 * math.pow(xi, 2)) )

				extra_term = rpho * (1 - gamma) * curr_step + (1 - rpho) * last_step

				last_step = curr_step

			# the same as orginal, for computing the gradients * subgradients
			rand_index = random.sample(xrange(num_examples), hessian_batch_size)
			sub_step = data_holder.batch_hess_vec_product(rand_index, curr_x, curr_step)
			curr_quad_step = curr_grad - sub_step
			curr_step = curr_step + init_gamma * curr_quad_step

			if initial_step:
				initial_step = False
				init_gamma = 1
				continue
			else:
				curr_step = extra_term + rpho * gamma * curr_step


		curr_x = curr_x -np.reshape(curr_step, data_holder.data_dim, 'F')

		print 'epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1]

	output_data = [epochs,  wall_times, trainerror]
	print(output_data)

	# min_train_error = min(trainerror)
	# for i in range(len(trainerror)):
	# 	trainerror[i] = np.log(trainerror[i] - min_train_error)



	# print(output_data)
	# f = open('1e-4_result_Rich1.'+data_holder.dataset, 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()


	# f = open('s2_500_Rich2.txt', 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	return curr_x, output_data


def g_two_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder, chebyshev_alpha, chebyshev_beta):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []

	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()

	for curr_iter in range(int(num_iter)):
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		#trainerror += [data_holder.batch_accuracy(range(0, num_examples), curr_x)]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)


		curr_grad = curr_grad.flatten('F')
		curr_step = np.zeros(curr_grad.shape)

		last_step = curr_grad
		initial_step = True

		# define the coefficients for the modified lissa iteration via  chebyshev semi iteration method

		alpha = 1.0 - chebyshev_beta
		beta = 1.0 - chebyshev_alpha
		xi = (2.0 - alpha - beta) / (beta - alpha)
		gamma = 2.0 / (2 - beta - alpha)
	#	rpho = 2.0/(1+pow((1-pow(((beta-alpha)/(beta+alpha)),2)),0.5))
		rpho = 2
		extra_term = np.zeros(curr_x.size)

		init_gamma = gamma

		for lissa_iter in range(num_lissa_iter):

			if not initial_step:

				# begin to apply chebyshev semi iteration
				#rpho = 1 / (1 - rpho / (4 * math.pow(xi, 2)) )

				extra_term = rpho * (1 - gamma) * curr_step + (1 - rpho) * last_step

				last_step = curr_step

			# the same as orginal, for computing the gradients * subgradients
			rand_index = random.sample(range(num_examples), hessian_batch_size)
			sub_step = data_holder.batch_hess_vec_product(rand_index, curr_x, curr_step)
			curr_quad_step = curr_grad - sub_step
			curr_step = curr_step + init_gamma * curr_quad_step

			if initial_step:
				initial_step = False
				init_gamma = 1
				continue
			else:
				curr_step = extra_term + rpho * gamma * curr_step


		curr_x = curr_x -np.reshape(curr_step, data_holder.data_dim, 'F')

		print('epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1])

	output_data = [epochs,  wall_times, trainerror]
	print(output_data)

	return curr_x, output_data

def two_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, quad_stepsize, data_holder, chebyshev_alpha, chebyshev_beta):
	num_examples = data_holder.num_train_examples
	curr_x = init_x

	epochs = []
	wall_times = []
	trainerror = []

	num_iter = num_epochs*num_examples*1.0/(outer_grad_size + num_lissa_iter*hessian_batch_size)
	start_time = time.time()

	for curr_iter in range(int(num_iter)):
		epochs += [curr_iter*(outer_grad_size + num_lissa_iter*hessian_batch_size)/num_examples]
		wall_times += [time.time() - start_time]
		#trainerror += [data_holder.batch_accuracy(range(0, num_examples), curr_x)]
		trainerror += [data_holder.batch_func(range(0, num_examples), curr_x)]
		curr_grad = data_holder.batch_grad(range(0, num_examples), curr_x)


		curr_grad = curr_grad.flatten('F')
		curr_step = np.zeros(curr_grad.shape)

		last_step = curr_grad
		initial_step = True

		# define the coefficients for the modified lissa iteration via  chebyshev semi iteration method

		alpha = 1.0 - chebyshev_beta
		beta = 1.0 - chebyshev_alpha
		xi = (2.0 - alpha - beta) / (beta - alpha)
		gamma = 2.0 / (2 - beta - alpha)
		rpho = 2.0/(1+pow((1-pow(((beta-alpha)/(beta+alpha)),2)),0.5))
	#	rpho = 1.2
		extra_term = np.zeros(curr_x.size)

		init_gamma = gamma

		for lissa_iter in range(num_lissa_iter):

			if not initial_step:

				# begin to apply chebyshev semi iteration
				#rpho = 1 / (1 - rpho / (4 * math.pow(xi, 2)) )

				extra_term = rpho * (1 - gamma) * curr_step + (1 - rpho) * last_step

				last_step = curr_step

			# the same as orginal, for computing the gradients * subgradients
			rand_index = random.sample(range(num_examples), hessian_batch_size)
			sub_step = data_holder.batch_hess_vec_product(rand_index, curr_x, curr_step)
			curr_quad_step = curr_grad - sub_step
			curr_step = curr_step + init_gamma * curr_quad_step

			if initial_step:
				initial_step = False
				init_gamma = 1
				continue
			else:
				curr_step = extra_term + rpho * gamma * curr_step


		curr_x = curr_x -np.reshape(curr_step, data_holder.data_dim, 'F')

		print('epochs', epochs[-1], 'wall_times', wall_times[-1], 'trainerror', trainerror[-1])

	output_data = [epochs,  wall_times, trainerror]
	print(output_data)


	# min_train_error = min(trainerror)
	# for i in range(len(trainerror)):
	# 	trainerror[i] = np.log(trainerror[i] - min_train_error)

	# f = open('1e-4_result_Rich2.'+data_holder.dataset, 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	# f = open('s2_25_Rich2.txt', 'w')
	# for i in epochs:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in wall_times:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.write('\n')
	# for i in trainerror:
	# 	i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
	# 	f.write(i)
	# f.close()

	return curr_x, output_data


def grad_descent(num_iter, init_x, stepsize, batch_size, data_holder):
	num_examples = data_holder.num_train_examples
	curr_x = init_x
	
	for curr_iter in range(num_iter):
		curr_grad = data_holder.batch_grad(random.sample(range(num_examples), batch_size), curr_x)
		curr_x = curr_x - stepsize*curr_grad

	return curr_x

