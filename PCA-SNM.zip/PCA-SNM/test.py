#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/4/9 3:38 下午
# @Contact : haozhou0806@gmail.com
# @Site    : https://zhouh.github.io/
# @File    : test.py



import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

lr = LogisticRegression(C=1)
lr.fit(X_train, y_train)