import numpy as np
import cPickle, gzip, math
from sklearn.preprocessing import normalize
from sklearn.datasets import load_svmlight_file

class DataHolder:
    def __init__(self, dataset = 'MNIST-softmax', lam = 0):
        self.lam = lam
        self.load_dataset(dataset)

    def load_dataset(self, dataset):
        if dataset == 'MNIST':
            print('-----------------------------------------------')
            print('Loading MNIST 4/9 data...')
            print('-----------------------------------------------\n')
            self.load_mnist_49()

            # MNIST uses logistic regression, other datasets use softmax, thus the shape of parameter is different
            self.data_dim = self.train_set[0][0].size
            self.dataset = 'MNIST'

        elif dataset == 'MNIST-softmax':
            print('-----------------------------------------------')
            print('Loading MNIST 4/9 data...')
            print('-----------------------------------------------\n')
            self.load_mnist_49_softmax()

            # MNIST uses logistic regression, other datasets use softmax, thus the shape of parameter is different
            self.dataset = 'MNIST-softmax'

        elif dataset == 'Real-sim':  # only support binary classification
            print '-----------------------------------------------'
            print 'Loading Real-sim data...'
            print('-----------------------------------------------\n')
            self.load_real_sim()
            self.data_dim = self.train_set[0][0].size
            self.dataset = 'Real-sim'


        elif dataset == 'CovType':
            print '-----------------------------------------------'
            print 'Loading cover type data...'
            print '-----------------------------------------------\n'
            self.load_cover_type()

            self.dataset = 'CovType'


        elif dataset == 'Mushroom':
            print '-----------------------------------------------'
            print 'Loading mushroom data...'
            print '-----------------------------------------------\n'
            self.load_mushroom()

            self.dataset = 'Mushroom'

        else:
            raise ValueError('No Dataset exists by that name')

        self.num_train_examples = self.train_set[0].shape[0]
        self.num_test_examples = self.test_set[0].shape[0]


    ### The following functions implement the logistic function oracles

    ## This is to load the 49 mnist
    def load_mnist_49(self):
        f = open('../data/mnist49data', 'rb')
        train_set, valid_set, test_set = cPickle.load(f)
        f.close()
        print train_set[1]
        self.train_set = [normalize(train_set[0], axis = 1, norm = 'l2'), train_set[1]]
        self.valid_set = [normalize(valid_set[0], axis = 1, norm = 'l2'), valid_set[1]]
        self.test_set = [normalize(test_set[0], axis = 1, norm = 'l2'), test_set[1]]
        print("training size:", self.train_set[0].shape[0])
        print("test size:", self.test_set[0].shape[0])
        print("validation size:", self.valid_set[0].shape[0])

    ## This is to load the 49 mnist
    def load_real_sim(self):
        f = open('../data/real-sim', 'rb')

        training_data = []
        training_label = []

        index = 1


        for line in f:
            s = line.strip().split(' ')
            training_label.append(int(s[0]))


            # new a new instance
            feature = np.zeros(20958) # 20598 is the total len of the feature

            for i in range(len(s) - 1):
                pair = s[i+1].split(':')
                # print 'pair', pair
                feature[int(pair[0]) -1] = float(pair[1])

            print (index)
            index += 1

            training_data.append(feature)

        self.train_set = [training_data[0:72000], training_label[0:72000]]
        self.valid_set =[training_data[72000:72150], training_label[72000:72150]]
        self.test_set = [training_data[72150:72300], training_label[72150:72300]]



        self.train_set = [normalize(self.train_set[0], axis = 1, norm = 'l2'), self.train_set[1]]
        self.valid_set = [normalize(self.valid_set[0], axis = 1, norm = 'l2'), self.valid_set[1]]
        self.test_set = [normalize(self.test_set[0], axis = 1, norm = 'l2'), self.test_set[1]]


        f.close()



    ## This is to load the 49 mnist
    def load_mnist_49_softmax(self):
        f = open('../data/mnist49data', 'rb')
        train_set, valid_set, test_set = cPickle.load(f)
        f.close()
        print train_set[1]
        self.train_set = [normalize(train_set[0], axis = 1, norm = 'l2'), train_set[1]]
        self.valid_set = [normalize(valid_set[0], axis = 1, norm = 'l2'), valid_set[1]]
        self.test_set = [normalize(test_set[0], axis = 1, norm = 'l2'), test_set[1]]


        class_set = np.unique(self.train_set[1]).tolist()
        self.c = len(class_set)

        self.train_set[1] = [class_set.index(i) for i in self.train_set[1]]
        self.valid_set[1] = [class_set.index(i) for i in self.valid_set[1]]
        self.test_set[1] = [class_set.index(i) for i in self.test_set[1]]


        print "training size:", self.train_set[0].shape[0]
        print "test size:", self.test_set[0].shape[0]
        print "validation size:", self.valid_set[0].shape[0]

        print train_set[1]

        self.data_dim = [self.train_set[0][0].size, self.c]

        print train_set[1]


    # converting feature to feature id, and return feature id and the total length of all kinds of feature
    def string2index(self, feature_list):
        feature_set = list(set(feature_list))

        feature_id = [feature_set.index(i) for i in feature_list]

        return feature_id, len(feature_set)

    def feature_id_to_onehot_feature(self, feature, feature_category):

        one_hot_feature = np.ones(0)

        if len(feature) != len(feature_category):
            print 'error! length dismatch'

        for i in range(len(feature)):
            # print 'feature i', type(feature[i]), type(feature_category[i])
            one_hot_feature_i = self.one_hot(feature[i], feature_category[i])
            one_hot_feature = np.concatenate( (one_hot_feature, one_hot_feature_i) )

        return one_hot_feature

    def load_mushroom(self):
        ## First implement the function for individuals

        f = open('../data/mushroom-agaricus-lepiota.data', 'rb')

        training_data = []
        training_label = []

        for line in f:
            s = line.split(',')
            training_label.append(s[0])


            training_data.append(list(s[1:-1]))
        print('loading done')

        print 'training label', len(training_label), training_label
        print 'training data', len(training_data), training_data[0:5]

        training_label, self.c = self.string2index(training_label)

        # print 'self.c0', self.c

        print 'label index', training_label

        feature_len = len(training_data[0])

        feature_list = []
        feature_category_len = []

        # print 'self.c1', self.c

        for i in range(feature_len):
            feature_i = [ instance_feature[i] for instance_feature in training_data ]
            feature_i, feature_len = self.string2index(feature_i)

            feature_category_len.append(feature_len)
            # one_hot_feature_i = list(np.eye(feature_len)[feature_i])
            feature_list.append(feature_i)

        # print 'self.c2', self.c

        training_data_with_feature_id = []
        for i in range(len(feature_list[0])):

            instance_with_feature_id = [ feature[i] for feature in feature_list ]
            instance_with_onehot_feature = self.feature_id_to_onehot_feature(instance_with_feature_id, feature_category_len)
            training_data_with_feature_id.append( instance_with_onehot_feature )

        # print 'self.c3', self.c

        training_data = training_data_with_feature_id

        print 'training data', training_data[0:5]
        print len(training_data)


        self.train_set = [training_data[0:7000], training_label[0:7000]]
        self.valid_set =[training_data[7000:7500], training_label[7000:7500]]
        self.test_set = [training_data[7500:8000], training_label[7500:8000]]

        self.train_set = [normalize(self.train_set[0], axis = 1, norm = 'l2'), self.train_set[1]]
        self.valid_set = [normalize(self.valid_set[0], axis = 1, norm = 'l2'), self.valid_set[1]]
        self.test_set = [normalize(self.test_set[0], axis = 1, norm = 'l2'), self.test_set[1]]

        self.data_dim = [self.train_set[0][0].size, self.c]

        print 'data dim', self.data_dim

        f.close()

    def load_cover_type(self):
        ## First implement the function for individuals

        f = open('../data/covtype.data', 'rb')

        training_data = []
        training_label = []

        for line in f:
            s = line.split(',')
            training_label.append(float(s[-1]))
            training_data.append(list( map(float, s[:-1]) ))
        print('loading done')

        class_set = np.unique(training_label).tolist()

        self.c = len(class_set)

        training_label = [class_set.index(i) for i in training_label]

        self.train_set = [np.array(training_data[0:80000]), training_label[0:80000]]
        self.valid_set =[np.array(training_data[80000:90000]), training_label[80000:90000]]
        self.test_set = [np.array(training_data[90000:100000]), training_label[90000:100000]]

        self.train_set = [normalize(self.train_set[0], axis = 1, norm = 'l2'), self.train_set[1]]
        self.valid_set = [normalize(self.valid_set[0], axis = 1, norm = 'l2'), self.valid_set[1]]
        self.test_set = [normalize(self.test_set[0], axis = 1, norm = 'l2'), self.test_set[1]]


        self.data_dim = [self.train_set[0][0].size, self.c]

        print 'data dim', self.data_dim

        f.close()

    def fetch_correct_datamode(self, mode = 'TRAIN'):
        if mode == 'TRAIN':
            return self.train_set
        elif mode == 'VALIDATE':
            return self.validate_set
        elif mode == 'TEST':
            return self.test_set
        else:
            raise ValueError('Wrong mode value provided')

    def logistic_indiv_func(self, data_index, model, mode='TRAIN'):
        data_set = self.fetch_correct_datamode(mode)
        v = -1.0*data_set[1][data_index]*np.dot(model, data_set[0][data_index])
        return np.log(np.exp(v) + 1)

    def logistic_indiv_grad(self, data_index, model):
        data_set = self.train_set
        v = -1.0*data_set[1][data_index]*np.dot(model, data_set[0][data_index])
        return -1*data_set[1][data_index]*data_set[0][data_index]*(np.exp(v)/(1 + np.exp(v)))

    def logistic_indiv_grad_coeff(self, data_index, model):
        data_set = self.train_set
        v = -1.0*data_set[1][data_index]*np.dot(model, data_set[0][data_index])
        return -1*data_set[1][data_index]*(np.exp(v)/(1 + np.exp(v)))

    def logistic_indiv_hess(self, data_index, model):
        data_set = self.train_set
        v = -1.0*data_set[1][data_index]*np.dot(model, data_set[0][data_index])
        # print 'v=', v
        # print np.exp(v)
        # print math.pow(np.exp(v),0.5)
        return (data_set[1][data_index])*((math.pow(np.exp(v),0.5))/(np.exp(v)+1))*data_set[0][data_index]

    def logistic_batch_func(self, data_batch, model):
        func_val = 0.0
        for data_indiv in data_batch:
            func_val += self.logistic_indiv_func(data_indiv, model, 'TRAIN')
        avg_func_val = func_val / len(data_batch)
        return avg_func_val + self.lam*np.dot(model, model)

    def logistic_accuracy(self, data_batch, model):
        func_val = 0.0
        for data_indiv in data_batch:
            v = np.dot(model, self.train_set[0][data_indiv])
            p = 1 / (np.exp(-1.0 * v)+1)
            y_hat = 1
            if p < 0.5:
                y_hat = -1
            if y_hat == self.train_set[1][data_indiv]:
                func_val += 1

        avg_func_val = func_val / len(data_batch)
        return avg_func_val



    def logistic_batch_grad(self, data_batch, model):
        batch_grad = np.zeros(self.data_dim)
        for data_indiv in data_batch:
            batch_grad += self.logistic_indiv_grad(data_indiv, model)
        avg_batch_grad = batch_grad / len(data_batch)
        return avg_batch_grad + 2*self.lam*model



    def logistic_batch_hess_full(self, data_batch, model):
        batch_hess = np.zeros((self.data_dim, self.data_dim))
        for data_indiv in data_batch:
            batch_hess += np.outer(self.logistic_indiv_hess(data_indiv, model), self.logistic_indiv_hess(data_indiv, model))
        avg_batch_hess = batch_hess / len(data_batch)
        return avg_batch_hess + 2*self.lam*np.identity(self.data_dim)

    def logistic_batch_hess_vec_product(self, data_batch, model, vector):
        hess_vec = np.zeros(self.data_dim)
        for data_indiv in data_batch:
            vtemp = self.logistic_indiv_hess(data_indiv, model)
            hess_vec += np.dot(vtemp, vector)*vtemp

        avg_hess_vec = hess_vec/len(data_batch)
        return avg_hess_vec + 2*self.lam*vector

    def test_error(self, model):
        func_val = 0.0
        data_batch = range(0, self.num_test_examples)
        for data_indiv in data_batch:
            func_val += self.logistic_indiv_func(data_indiv, model, 'TEST')
        avg_func_val = func_val / len(data_batch)
        return avg_func_val

    def error_01(self, model, mode='TRAIN'):
        data_set = self.fetch_correct_datamode(mode)
        num_examples = data_set[0].shape[0]
        error = 0
        for i in range(num_examples):
            error += abs(np.sign(np.dot(model, data_set[0][i])) - data_set[1][i])/2

        return error/num_examples


    # fucntions for softmax
    # details of softmax computing, or softmax's deratives could refer to:https://towardsdatascience.com/softmax-regression-in-python-multi-class-classification-3cb560d90cb2 and https://towardsdatascience.com/derivative-of-the-softmax-function-and-the-categorical-cross-entropy-loss-ffceefc081d1

    def softmax(self, z):
        # z--> linear part.
        # print 'z', z
        # subtracting the max of z for numerical stability.
        exp = np.exp(z - np.max(z))

        # print 'max', np.max(z)
        #
        # print 'z', z
        # print 'exp', exp

        # Calculating softmax for all examples.

        # print 'len', len(z)

        sum = np.sum(exp)

        for i in range(len(z)):
            exp[i] /= sum

        # print 'exp2', exp

        # print 'exp', exp
        return exp

    def one_hot(self, y, c):
        # y--> label/ground truth.
        # c--> Number of classes.

        # A zero matrix of size (m, c)
        y_hot = np.zeros(c)

        # Putting 1 for column where the label is,
        # Using multidimensional indexing.
        y_hot[y] = 1


        # print 'y', y
        # print 'y_hot', y_hot

        return y_hot

    def softmax_indiv_func(self, data_index, model, mode='TRAIN'):
        data_set = self.fetch_correct_datamode(mode)

        y_hat = self.softmax(np.dot(data_set[0][data_index], model))
        y = data_set[1][data_index]

        # print 'yhat', y_hat
        # print 'y', y

        return -1.0 * np.log(y_hat[y])
        # return y_hat[y]



    def accuracy(self, data_batch, model):
        func_val = 0.0

        print "accuracy"

        for data_indiv in data_batch:

            y_hat = np.argmax(np.dot(self.train_set[0][data_indiv], model))
            y = self.train_set[1][data_indiv]

            if y == y_hat:
                func_val += 1

        avg_func_val = func_val / len(data_batch)
        # return avg_func_val + self.lam * np.sum(model*model)

        return avg_func_val



    def softmax_indiv_grad(self, data_index, model):
        data_set = self.train_set

        logics = np.dot(data_set[0][data_index], model)

        y_hat = self.softmax(logics)
        y = data_set[1][data_index]

        # print 'ds1', data_set[1]

        error = y_hat - self.one_hot(y, self.c)

        g = np.outer(data_set[0][data_index], error)

        return g


    # def softmax_indiv_grad_coeff(self, data_index, model):
    #     data_set = self.train_set
    #     v = -1.0*data_set[1][data_index]*np.dot(model, data_set[0][data_index])
    #     return -1*data_set[1][data_index]*(np.exp(v)/(1 + np.exp(v))v)

    def softmax_indiv_hess(self, data_index, model):
        data_set = self.train_set
        y_hat = self.softmax(np.dot(data_set[0][data_index], model))
        # print 'v=', v
        # print np.exp(v)
        # print math.pow(np.exp(v),0.5)

        # print 's', y_hat
        # print 's(1-s)', y_hat * (1-y_hat)

        H = np.kron( np.diag(y_hat) - np.outer(y_hat, y_hat), np.outer(data_set[0][data_index], data_set[0][data_index]) )

        return H
        # return  (y_hat * (1 - y_hat))

    def softmax_batch_func(self, data_batch, model):

        print 'loss'

        func_val = 0.0
        for data_indiv in data_batch:
            func_val += self.softmax_indiv_func(data_indiv, model, 'TRAIN')
        avg_func_val = func_val / len(data_batch)
        return avg_func_val
        # return avg_func_val + self.lam*np.sum(model * model)

    def softmax_batch_grad(self, data_batch, model):
        batch_grad = np.zeros(self.data_dim)
        for data_indiv in data_batch:
            batch_grad += self.softmax_indiv_grad(data_indiv, model)
        avg_batch_grad = batch_grad / len(data_batch)
        # return avg_batch_grad + 2*self.lam*model
        return avg_batch_grad
    #
    # def softmax_batch_hess_full(self, data_batch, model):
    #     batch_hess = np.zeros((self.data_dim, self.data_dim))
    #     for data_indiv in data_batch:
    #         batch_hess += np.outer(self.softmax_indiv_hess(data_indiv, model), self.softmax_indiv_hess(data_indiv, model))
    #     avg_batch_hess = batch_hess / len(data_batch)
    #     return avg_batch_hess + 2*self.lam*np.identity(self.data_dim)
    #
    def softmax_batch_hess_vec_product(self, data_batch, model, vector):
        hess_vec = np.zeros(vector.shape)
        for data_indiv in data_batch:
            hessian = self.softmax_indiv_hess(data_indiv, model)

            hess_vec += np.dot(hessian, vector)

        avg_hess_vec = hess_vec/len(data_batch)
        return avg_hess_vec +  2*self.lam*vector
        # return avg_hess_vec

    def batch_grad(self, data_batch, model):
        if self.dataset == 'MNIST' or self.dataset == 'Real-sim':
            return self.logistic_batch_grad(data_batch, model)
        else:
            return self.softmax_batch_grad(data_batch, model)

    def batch_hess_vec_product(self,  data_batch, model, vector):
        if self.dataset == 'MNIST' or self.dataset == 'Real-sim':
            return self.logistic_batch_hess_vec_product(data_batch, model, vector)
        else:
            return self.softmax_batch_hess_vec_product(data_batch, model, vector)

    def batch_func(self,  data_batch, model):
        if self.dataset == 'MNIST' or self.dataset == 'Real-sim':
            return self.logistic_batch_func(data_batch, model)
        else:
            return self.softmax_batch_func(data_batch, model)


    def batch_accuracy(self,  data_batch, model):
        if self.dataset == 'MNIST' or self.dataset == 'Real-sim':
            return self.logistic_accuracy(data_batch, model)
        else:
            return self.accuracy(data_batch, model)
