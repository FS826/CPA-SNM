from logistic_oracles import *
from lissa import *
import numpy as np
import cPickle
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', default='Mushroom', type=str)# MNIST  CovType  Mushroom  Real-sim

args = parser.parse_args()
data_holder = DataHolder(lam=1e-4, dataset = args.dataset)
# data_holder = DataHolder(lam=1e-4, dataset = 'Mushroom')
num_examples = data_holder.num_train_examples


parser.add_argument('--num_epochs', default=60, type=int)
parser.add_argument('--num_lissa_iter', default=25, type=int)
parser.add_argument('--outer_grad_size', default=num_examples, type=int)
parser.add_argument('--hessian_batch_size', default=1, type=int)
parser.add_argument('--stepsize', default=1.0, type=float)

# define the alpha & beta as hyperparameters for the chebyshev semi iteration trick
parser.add_argument('--chebyshev_alpha', default=0.2, type=float)
parser.add_argument('--chebyshev_beta', default=0.8, type=float)


args = parser.parse_args()



rng = np.random.RandomState(313)

if isinstance(data_holder.data_dim, list):
    gd_init_x = 0.001 *  rng.randn(*data_holder.data_dim ).astype(np.float32)
else:
    gd_init_x = 0.001 *  rng.randn(data_holder.data_dim ).astype(np.float32)

gd_iter = 50
gd_stepsize = 5.0
init_x = grad_descent(gd_iter, gd_init_x, gd_stepsize, num_examples, data_holder)
# init_x = gd_init_x

num_epochs = args.num_epochs
num_lissa_iter = args.num_lissa_iter
outer_grad_size = args.outer_grad_size
hessian_batch_size = args.hessian_batch_size
stepsize = args.stepsize

# initialiazation for hyper-parameters
chebyshev_alpha = args.chebyshev_alpha
chebyshev_beta = args.chebyshev_beta

print('-----------------------------------------------')
print('Training model...')
print('-----------------------------------------------\n')

f = open('../output/LiSSAOutputMNIST','wb')

# if args.dataset == 'MNIST':
#     func = lissa_main
# else if args.dataset == 'MNIST':
#     func = lissa_chebyshev_semi_iteration


result, output_data1 = lissa_main(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder)
result, output_data2 = lissa_chebyshev_semi_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)
result, output_data3 = one_step_Richardson_iteration(init_x, num_epochs,num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)
result, output_data4 = g_two_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)
result, output_data5 = two_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)



min_loss = min(output_data1[2] + output_data2[2] + output_data3[2] +  output_data5[2])

for i in range(len(output_data1[2])):
    output_data1[2][i] = np.log(output_data1[2][i] - min_loss)


for i in range(len(output_data2[2])):
    output_data2[2][i] = np.log(output_data2[2][i] - min_loss)


for i in range(len(output_data3[2])):
    output_data3[2][i] = np.log(output_data3[2][i] - min_loss)


for i in range(len(output_data4[2])):
    output_data4[2][i] = np.log(output_data4[2][i] - min_loss)

for i in range(len(output_data5[2])):
    output_data5[2][i] = np.log(output_data5[2][i] - min_loss)


def write_file(output_data, file_name):

    epochs = output_data[0]
    wall_times = output_data[1]
    trainerror = output_data[2]

    f = open(file_name, 'w')
    for i in epochs:
        i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
        f.write(i)
    f.write('\n')
    for i in wall_times:
        i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
        f.write(i)
    f.write('\n')
    for i in trainerror:
        i = str(i).strip('[').strip(']').replace(',', '').replace('\'', '') + ' '
        f.write(i)
    f.close()


write_file(output_data1, './newdata/f3/Mushroom_lissa_rho2.txt')

write_file(output_data2, './newdata/f3/Mushroom_cheb_rho2.txt')

write_file(output_data3, './newdata/f3/Mushroom_oneR_rho2.txt')

write_file(output_data4, './newdata/f3/Mushroom_gtwoR_rho2.txt')

write_file(output_data5, './newdata/f3/Mushroom_twoR_rho2.txt')

cPickle.dump(output_data5, f)
f.close()


#f = open('../output/LiSSAOutputMNIST','wb')
#result, output_data = lissa_chebyshev_semi_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)
#result, output_data = two_step_Richardson_iteration(init_x, num_epochs, num_lissa_iter, outer_grad_size, hessian_batch_size, stepsize, data_holder, chebyshev_alpha, chebyshev_beta)
#cPickle.dump(output_data, f)
#f.close()



print('-----------------------------------------------')
print('Training complete')
print('-----------------------------------------------')

#x = epochs
#y = trainerror
#plt.plot(x, y)
#plt.xlabel('Iterations')
#plt.ylabel('log(error)')
#plt.title('MNIST,Lambda=1E-4')
#plt.show()